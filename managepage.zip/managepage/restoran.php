<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Account Page | Sasufima</title>
        <meta name="viewport" content="initial-scale=1, width=device-width" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
        <style>
            * {
                margin: 0;
                padding: 0;
                font-family: 'Open Sans', sans-serif;
                font-family: 'Poppins', sans-serif;
            }

            .recentdata {
                padding: 50px 0;
                background: #FFE6D2;
            }

            .title {
                padding: 2% 10%;
            }

            .title h1 {
                font-weight: 600;
                font-size: 48px;
                line-height: 58px;
                color: #232536;
            }

            .amount {
                margin-left: 30px;
                width: 80%;
                display: flex;
                margin: auto;
                justify-content: space-between;
            }

            .container {
                background: #FFFFFF;
                flex-basis: 30%;
                box-sizing: border-box;
            }

            .container h2 {
                font-weight: 600;
                font-size: 24px;
                line-height: 36px;
                color: #232536;
                padding: 15px 0;
                margin-left: 25px;
                margin-right: 25px;
                text-align: center;
            }

            .container  h3 {
                font-weight: 600;
                font-size: 36px;
                line-height: 36px;
                color: #232536;
                padding: 15px 0;
                margin-left: 25px;
                margin-right: 25px;
                text-align: right;
            }

            .container  h4 {
                font-weight: 500;
                font-size: 18px;
                line-height: 36px;
                color: #232536;
                padding: 15px 0;
                margin-left: 75px;
                margin-right: 75px;
                text-align: justify;
            }

            .showtable {
                margin-left: 25%;
                width: 50%;
                padding: 50px 0;
                justify-content: space-between;
            }

            .showtable h2 {
                font-weight: 600;
                font-size: 24px;
                line-height: 36px;
                color: #232536;
                padding: 15px 0;
                margin-left: 25px;
                margin-right: 25px;
                text-align: center;
            }

            table {
                border-collapse: collapse;
                width: 100%;
                color: #232536;
                font-weight: 500;
                font-size: 16px;
                text-align: center;
            }

            th {
                background-color: #232536;
                color: #E5E5E5 ;
                text-align: center;
                padding: 15px 0;
            }

            tr:nth-child(even) {background-color: #E5E5E5 ;}
        </style>
    </head>
    <body>
        <div class="recentdata">
            <div class="title">
                <h1>Your recent data</h1>
            </div>
            <div class="amount"> 
                <div class="container"> 
                    <h2>Profit</h2>
                    <h3>Rp
                    <?php
                    $conn = mysqli_connect("localhost", "root", "", "restoran");
                    // Check connection
                    if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                    }
                    $sql = "SELECT item_terjual, gross_profit, SUM(item_terjual*gross_profit) as TOTAL FROM penjualan";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["TOTAL"]. "</td><td>" . "</td></tr>";
                    }
                    echo "</table>";
                    } else { echo "0 results"; }
                    $conn->close();
                    ?>
                    </h3>
                </div>
                <div class="container"> 
                    <h2>Sold Data</h2>
                    <h4> <b>
                        <?php
                        $conn = mysqli_connect("localhost", "root", "", "restoran");
                        // Check connection
                        if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                        }
                        $sql = "SELECT item_terjual, SUM(item_terjual) as TOTAL FROM penjualan";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["TOTAL"]. "</td><td>" . "</td></tr>";
                        }
                        echo "</table>";
                        } else { echo "0 results"; }
                        $conn->close();
                        ?> </b>
                        item makanan dan minuman yang terjual
                    </h4>
                </div>
            </div>
            <div class="showtable">
                <h2>Your Sales Table</h2>
                <table>
                    <tr>
                        <th>Nama</th>
                        <th>Item Terjual</th>
                        <th>Gross Profit</th>
                        <th>Kategori</th>
                        <th>Tanggal</th>
                    </tr>
                    <?php
                    $conn = mysqli_connect("localhost", "root", "", "restoran");
                    // Check connection
                    if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                    }
                    $sql = "SELECT nama_item, item_terjual, gross_profit, kategori_item, tanggal FROM penjualan";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["nama_item"]. "</td><td>" . $row["item_terjual"]. "</td><td>" . $row["gross_profit"]. "</td><td>" . $row["kategori_item"] . "</td><td>"
                    . $row["tanggal"]. "</td></tr>";
                    }
                    echo "</table>";
                    } else { echo "0 results"; }
                    $conn->close();
                    ?>
                </table>
            </div>
        </div>
    </body>
</html>